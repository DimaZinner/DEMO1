﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Demo
{
    public partial class AuthForm : Form
    {
        private DataBase db;

        public AuthForm()
        {
            InitializeComponent();
            db = new DataBase();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtLogin.Text;
            string password = txtPass.Text;

            // Получаем ID роли пользователя
            int roleId = db.ValidateUser(username, password);

            if (roleId != -1)
            {
                MessageBox.Show("Авторизация успешна!");

                // Открываем ProductForm и передаем роль пользователя
                ProductForm productForm = new ProductForm(roleId); // Передаем роль
                productForm.Show();

                this.Hide(); // Скрываем форму авторизации
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль!");
            }
        }
    }
}
